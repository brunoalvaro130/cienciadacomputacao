
package App;


public class ProdutoAcabado extends Produto {
    private int estoque;
    private String loja;

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }
    

    public String getLoja() {
        return loja;
    }

    public void setLoja(String loja) {
        this.loja = loja;
    }

    

    

    
    
    
    
    
    
    
    
}

